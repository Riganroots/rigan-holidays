const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");
const filterButtons = document.querySelectorAll(".filter-btn");
const packageCards = document.querySelectorAll(".package-card");
const tripForm = document.getElementById("tripForm");
const year = document.getElementById("year");

year.textContent = new Date().getFullYear();

menuToggle.addEventListener("click", () => {
  navLinks.classList.toggle("open");
});

document.querySelectorAll(".nav-links a").forEach((link) => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
  });
});

filterButtons.forEach((button) => {
  button.addEventListener("click", () => {
    filterButtons.forEach((btn) => btn.classList.remove("active"));
    button.classList.add("active");

    const filter = button.dataset.filter;

    packageCards.forEach((card) => {
      const categories = card.dataset.category;
      if (filter === "all" || categories.includes(filter)) {
        card.classList.remove("hidden");
      } else {
        card.classList.add("hidden");
      }
    });
  });
});

tripForm.addEventListener("submit", (event) => {
  event.preventDefault();

  const formData = new FormData(tripForm);
  const data = Object.fromEntries(formData.entries());

  const phoneNumber = "9779800000000"; // Replace with your real WhatsApp number.

  const message = `
Hello Rigan Holidays,

I want to plan an international trip.

Name: ${data.name}
Phone: ${data.phone}
Email: ${data.email || "Not provided"}
Destination: ${data.destination}
Travelers: ${data.travelers || "Not provided"}
Travel Date: ${data.date || "Not provided"}
Budget: ${data.budget || "Not provided"}
Trip Type: ${data.type || "Not provided"}
Message: ${data.message || "Not provided"}
  `.trim();

  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;
  window.open(whatsappUrl, "_blank");
});

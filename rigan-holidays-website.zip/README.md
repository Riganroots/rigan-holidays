# Rigan Holidays Website

Static outbound travel agency website for **Rigan Holidays** by **Rigan Roots & Routes**.

## Files

- `index.html` - Main website page
- `style.css` - Website design and responsive layout
- `script.js` - Mobile menu, package filter, and WhatsApp inquiry form

## How to edit

1. Replace phone number in `index.html` WhatsApp floating link.
2. Replace phone number in `script.js`:
   ```js
   const phoneNumber = "9779800000000";
   ```
3. Replace email, phone, and address in the Contact section.
4. Replace package names, destinations, and prices as needed.

## GitHub Pages

Upload these files to the root of your repository and publish from the `main` branch using GitHub Pages.
